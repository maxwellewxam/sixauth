'''An all-in-one user authenticator and data manager'''
from .main.__main__ import *
__all__ = ['LocationError', 'AuthenticationError', 'UsernameError', 'PasswordError', 'AuthSesh']