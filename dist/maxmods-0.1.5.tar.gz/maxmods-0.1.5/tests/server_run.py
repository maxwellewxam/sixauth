from maxmods.auth.auth_backend import start_server
start_server('127.0.0.1', 5678)