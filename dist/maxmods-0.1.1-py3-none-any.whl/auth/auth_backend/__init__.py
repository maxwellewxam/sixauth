'''Backend module for the Auth module'''
from .__main__ import *
__all__ = ['start_server']