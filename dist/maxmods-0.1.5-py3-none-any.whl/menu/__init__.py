'''Simple textual menu module for easy creation of menus'''
from .__main__ import *
__all__ = ['CallerError', 'Base', 'basicMenu', 'infoMenu', 'settingsMenu']