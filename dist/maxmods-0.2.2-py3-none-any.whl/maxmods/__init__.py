'''My Library of modules because im too lazy to make more then one spot for these at the moment.'''
